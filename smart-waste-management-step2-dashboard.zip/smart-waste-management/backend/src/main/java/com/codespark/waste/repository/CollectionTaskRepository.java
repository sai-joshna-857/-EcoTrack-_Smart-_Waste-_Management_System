package com.codespark.waste.repository;

import com.codespark.waste.model.CollectionTask;
import com.codespark.waste.model.CollectionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CollectionTaskRepository extends JpaRepository<CollectionTask, Long> {
    long countByStatus(CollectionStatus status);
}
