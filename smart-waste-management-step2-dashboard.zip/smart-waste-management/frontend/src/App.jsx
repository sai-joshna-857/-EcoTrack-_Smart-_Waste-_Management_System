import React, { useEffect, useMemo, useState } from 'react';

const API = 'http://localhost:8080/api';

function App() {
  const [activePage, setActivePage] = useState('Dashboard');
  const [summary, setSummary] = useState({});
  const [bins, setBins] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState('');

  async function loadDashboard() {
    try {
      const [summaryRes, binsRes, tasksRes] = await Promise.all([
        fetch(`${API}/dashboard/summary`),
        fetch(`${API}/bins`),
        fetch(`${API}/collections`)
      ]);
      if (!summaryRes.ok || !binsRes.ok || !tasksRes.ok) throw new Error('API error');
      setSummary(await summaryRes.json());
      setBins(await binsRes.json());
      setTasks(await tasksRes.json());
      setError('');
    } catch {
      setError('Backend is not connected. Start Spring Boot and MySQL, then click Refresh.');
    }
  }

  useEffect(() => { loadDashboard(); }, []);

  const categoryCounts = useMemo(() => {
    const names = ['WET', 'DRY', 'PLASTIC', 'E_WASTE'];
    return names.map(name => ({ name: name.replace('_', ' '), count: bins.filter(b => b.category === name).length }));
  }, [bins]);

  const cards = [
    { label: 'Total waste bins', value: summary.totalBins ?? 0, icon: '▦', color: 'teal' },
    { label: 'Full bins', value: summary.fullBins ?? 0, icon: '▣', color: 'red' },
    { label: 'Half-full bins', value: summary.halfFullBins ?? 0, icon: '◧', color: 'amber' },
    { label: 'Empty bins', value: summary.emptyBins ?? 0, icon: '□', color: 'green' },
    { label: 'Pending collections', value: summary.pendingCollections ?? 0, icon: '◷', color: 'blue' },
    { label: 'Completed collections', value: summary.completedCollections ?? 0, icon: '✓', color: 'purple' }
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">♻</div><div><b>EcoTrack</b><small>WASTE MANAGEMENT</small></div></div>
        <div className="nav-caption">WORKSPACE</div>
        {['Dashboard', 'Waste Bins', 'Waste Categories', 'Collection Teams', 'Collection Schedule', 'Collection History'].map((item, i) => (
          <button key={item} className={`nav-item ${activePage === item ? 'active' : ''}`} onClick={() => setActivePage(item)}>
            <span className="nav-icon">{['▦','▤','◈','♧','▣','↻'][i]}</span>{item}
          </button>
        ))}
        <div className="sidebar-bottom"><div className="user-avatar">A</div><div><b>Administrator</b><small>System admin</small></div></div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div><span className="breadcrumb">Workspace /</span> <b>{activePage}</b></div>
          <div className="top-actions"><span className="system-status"><i></i> System online</span><button className="refresh-btn" onClick={loadDashboard}>↻ Refresh</button><div className="top-avatar">A</div></div>
        </header>

        <div className="content">
          <section className="welcome-row">
            <div><p className="eyebrow">CODESPARK HACKATHON 2026 · TOPIC 46</p><h1>{activePage}</h1><p className="muted">Monitor waste bins and keep collection operations organized.</p></div>
            <div className="date-chip">♧ &nbsp; Smart city operations</div>
          </section>

          {error && <div className="alert">{error}</div>}

          {activePage === 'Dashboard' ? <>
            <section className="metric-grid">
              {cards.map(card => <article className="metric-card" key={card.label}><div className={`metric-icon ${card.color}`}>{card.icon}</div><div className="metric-label">{card.label}</div><div className="metric-value">{card.value}</div><div className="metric-foot">Live database count</div></article>)}
            </section>

            <section className="dashboard-grid">
              <article className="panel chart-panel">
                <div className="panel-heading"><div><h2>Waste bin status</h2><p>Current status of all registered bins</p></div><span className="tag">Live overview</span></div>
                <div className="status-visual">
                  <div className="donut" style={{'--full': `${(summary.fullBins || 0) / Math.max(summary.totalBins || 1, 1) * 100}%`, '--half': `${(summary.halfFullBins || 0) / Math.max(summary.totalBins || 1, 1) * 100}%`}}><div><b>{summary.totalBins ?? 0}</b><small>Total bins</small></div></div>
                  <div className="legend">
                    <div><i className="dot red-dot"></i><span>Full bins</span><b>{summary.fullBins ?? 0}</b></div>
                    <div><i className="dot amber-dot"></i><span>Half-full bins</span><b>{summary.halfFullBins ?? 0}</b></div>
                    <div><i className="dot green-dot"></i><span>Empty bins</span><b>{summary.emptyBins ?? 0}</b></div>
                  </div>
                </div>
              </article>

              <article className="panel category-panel">
                <div className="panel-heading"><div><h2>Waste categories</h2><p>Registered bins by waste type</p></div></div>
                {categoryCounts.map(c => <div className="category-row" key={c.name}><span>{c.name}</span><div className="bar-track"><div className="bar-fill" style={{width: `${bins.length ? c.count / bins.length * 100 : 0}%`}}></div></div><b>{c.count}</b></div>)}
                {!bins.length && <p className="empty-hint">Add bins to see category statistics.</p>}
              </article>
            </section>

            <section className="panel table-panel">
              <div className="panel-heading"><div><h2>Recent waste bins</h2><p>Latest bins registered in the system</p></div><button className="text-button" onClick={() => setActivePage('Waste Bins')}>View all →</button></div>
              <div className="table-scroll"><table><thead><tr><th>BIN CODE</th><th>LOCATION</th><th>WASTE CATEGORY</th><th>STATUS</th></tr></thead><tbody>
                {bins.slice(-5).reverse().map(bin => <tr key={bin.id}><td><b>{bin.binCode}</b></td><td>{bin.location}</td><td>{bin.category?.replace('_',' ')}</td><td><span className={`status-pill ${bin.status?.toLowerCase()}`}>{bin.status?.replace('_',' ')}</span></td></tr>)}
                {!bins.length && <tr><td colSpan="4" className="empty-hint">No bins yet. Add your first bin in Waste Bin Management.</td></tr>}
              </tbody></table></div>
            </section>

            <section className="panel table-panel">
              <div className="panel-heading"><div><h2>Collection activity</h2><p>Recently scheduled collection tasks</p></div><button className="text-button" onClick={() => setActivePage('Collection History')}>View history →</button></div>
              <div className="table-scroll"><table><thead><tr><th>BIN ID</th><th>COLLECTION TEAM</th><th>SCHEDULED DATE</th><th>STATUS</th></tr></thead><tbody>
                {tasks.slice(-5).reverse().map(t => <tr key={t.id}><td>BIN-{String(t.binId).padStart(3,'0')}</td><td>{t.teamName}</td><td>{t.scheduledDate}</td><td><span className={`status-pill ${t.status?.toLowerCase()}`}>{t.status}</span></td></tr>)}
                {!tasks.length && <tr><td colSpan="4" className="empty-hint">No collection tasks scheduled yet.</td></tr>}
              </tbody></table></div>
            </section>
          </> : <section className="panel coming-soon"><div className="coming-icon">♻</div><h2>{activePage}</h2><p>This module will be connected in the next development step.</p><button onClick={() => setActivePage('Dashboard')}>Back to dashboard</button></section>}
          <footer>EcoTrack · Smart Waste Management System <span>Built for CODESPARK HACKATHON 2026</span></footer>
        </div>
      </main>
    </div>
  );
}
export default App;
