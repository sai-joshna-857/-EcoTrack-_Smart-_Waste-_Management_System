package com.codespark.waste.controller;

import com.codespark.waste.model.WasteBin;
import com.codespark.waste.repository.WasteBinRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/bins")
public class BinController {
    private final WasteBinRepository repository;
    public BinController(WasteBinRepository repository) { this.repository = repository; }

    @GetMapping public List<WasteBin> getAll() { return repository.findAll(); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public WasteBin create(@Valid @RequestBody WasteBin bin) { return repository.save(bin); }
    @PutMapping("/{id}")
    public WasteBin update(@PathVariable Long id, @Valid @RequestBody WasteBin input) {
        WasteBin bin = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Bin not found"));
        bin.setBinCode(input.getBinCode());
        bin.setLocation(input.getLocation());
        bin.setCategory(input.getCategory());
        bin.setStatus(input.getStatus());
        return repository.save(bin);
    }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { repository.deleteById(id); }
}
