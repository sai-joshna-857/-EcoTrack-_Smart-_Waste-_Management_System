package com.codespark.waste.controller;

import com.codespark.waste.model.CollectionTask;
import com.codespark.waste.repository.CollectionTaskRepository;
import com.codespark.waste.repository.WasteBinRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/collections")
public class CollectionController {
    private final CollectionTaskRepository tasks;
    private final WasteBinRepository bins;
    public CollectionController(CollectionTaskRepository tasks, WasteBinRepository bins) {
        this.tasks = tasks; this.bins = bins;
    }
    @GetMapping public List<CollectionTask> getAll() { return tasks.findAll(); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public CollectionTask create(@Valid @RequestBody CollectionTask task) {
        if (!bins.existsById(task.getBinId()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Selected bin does not exist");
        return tasks.save(task);
    }
}
