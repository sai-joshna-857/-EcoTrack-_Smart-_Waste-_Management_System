# Smart Waste Management System (Topic 46)

Starter MVP using React + Java Spring Boot + MySQL. It includes:
- Waste-bin CRUD (create, list, update status, delete)
- Collection-task creation and listing
- Dashboard summary counts
- A small optional Python waste-generation prediction example

## Prerequisites
- Java 17+
- Maven 3.9+
- Node.js 20+
- MySQL 8+

## 1. Create the database
```sql
CREATE DATABASE smart_waste_db;
```

## 2. Run the backend
```bash
cd backend
mvn spring-boot:run
```
The API runs at `http://localhost:8080`.

For a local MySQL setup, edit `backend/src/main/resources/application.properties`.
Default credentials are `root` / `root`; change them to your own MySQL credentials.

## 3. Run the frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (normally `http://localhost:5173`).

## API endpoints
- `GET /api/bins`
- `POST /api/bins`
- `PUT /api/bins/{id}`
- `DELETE /api/bins/{id}`
- `GET /api/collections`
- `POST /api/collections`
- `GET /api/dashboard/summary`

## MVP notes
- Bin status values: `EMPTY`, `HALF_FULL`, `FULL`
- Waste categories: `WET`, `DRY`, `PLASTIC`, `E_WASTE`
- Collection status values: `PENDING`, `COMPLETED`
- This is a development starter, not a production-secured deployment. Add authentication/authorization before real use.
- The Python file is an optional demonstration using a simple rule-based estimate; it is not a trained machine-learning model.
