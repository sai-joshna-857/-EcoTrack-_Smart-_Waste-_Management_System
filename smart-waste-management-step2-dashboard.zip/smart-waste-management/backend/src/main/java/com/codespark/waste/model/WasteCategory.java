package com.codespark.waste.model;

public enum WasteCategory { WET, DRY, PLASTIC, E_WASTE }
