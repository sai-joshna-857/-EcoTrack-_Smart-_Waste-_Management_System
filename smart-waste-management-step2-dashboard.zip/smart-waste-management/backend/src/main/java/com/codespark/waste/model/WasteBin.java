package com.codespark.waste.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "waste_bins")
public class WasteBin {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank private String binCode;
    @NotBlank private String location;
    @Enumerated(EnumType.STRING) @NotNull private WasteCategory category;
    @Enumerated(EnumType.STRING) @NotNull private BinStatus status = BinStatus.EMPTY;

    public Long getId() { return id; }
    public String getBinCode() { return binCode; }
    public void setBinCode(String binCode) { this.binCode = binCode; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public WasteCategory getCategory() { return category; }
    public void setCategory(WasteCategory category) { this.category = category; }
    public BinStatus getStatus() { return status; }
    public void setStatus(BinStatus status) { this.status = status; }
}
