package com.codespark.waste.model;

public enum CollectionStatus { PENDING, COMPLETED }
