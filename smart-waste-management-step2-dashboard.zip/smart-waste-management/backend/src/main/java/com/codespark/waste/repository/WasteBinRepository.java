package com.codespark.waste.repository;

import com.codespark.waste.model.WasteBin;
import com.codespark.waste.model.BinStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteBinRepository extends JpaRepository<WasteBin, Long> {
    long countByStatus(BinStatus status);
}
