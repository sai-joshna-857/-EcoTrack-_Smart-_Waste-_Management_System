package com.codespark.waste.controller;

import com.codespark.waste.model.BinStatus;
import com.codespark.waste.model.CollectionStatus;
import com.codespark.waste.repository.WasteBinRepository;
import com.codespark.waste.repository.CollectionTaskRepository;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final WasteBinRepository bins;
    private final CollectionTaskRepository tasks;
    public DashboardController(WasteBinRepository bins, CollectionTaskRepository tasks) {
        this.bins = bins; this.tasks = tasks;
    }
    @GetMapping("/summary")
    public Map<String, Long> summary() {
        return Map.of(
            "totalBins", bins.count(),
            "fullBins", bins.countByStatus(BinStatus.FULL),
            "halfFullBins", bins.countByStatus(BinStatus.HALF_FULL),
            "emptyBins", bins.countByStatus(BinStatus.EMPTY),
            "pendingCollections", tasks.countByStatus(CollectionStatus.PENDING),
            "completedCollections", tasks.countByStatus(CollectionStatus.COMPLETED)
        );
    }
}
