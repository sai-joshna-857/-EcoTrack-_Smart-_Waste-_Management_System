# Optional demonstration only: replace this rule-based estimate with a trained model
# when your team has real collection-history data.
def predict_next_fill_level(current_level_percent, daily_increase_percent):
    predicted = min(100, max(0, current_level_percent + daily_increase_percent))
    if predicted >= 80:
        return {"predicted_level": predicted, "recommendation": "Collect soon"}
    return {"predicted_level": predicted, "recommendation": "Collection not urgent"}

if __name__ == "__main__":
    print(predict_next_fill_level(65, 20))
