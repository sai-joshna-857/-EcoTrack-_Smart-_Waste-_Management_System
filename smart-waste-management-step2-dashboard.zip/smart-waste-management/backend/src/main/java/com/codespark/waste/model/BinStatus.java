package com.codespark.waste.model;

public enum BinStatus { EMPTY, HALF_FULL, FULL }
